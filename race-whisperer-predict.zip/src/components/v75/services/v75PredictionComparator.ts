
import { V75PostRaceAnalysis, V75RaceAnalysis, V75PredictionAccuracy } from '../types/postRaceAnalysisTypes';
import { V75CacheService } from '../../../services/v75CacheService';
import { RaceAnalysisData } from '../../../services/v75Cache/types';

export class V75PredictionComparator {
  /**
   * Compare cached predictions with actual race results - NO FALLBACK REGENERATION
   */
  static async compareWithPredictions(
    analysisDate: string,
    actualResults: any[]
  ): Promise<V75PostRaceAnalysis> {

    const races: V75RaceAnalysis[] = [];
    
    // Get all cached race analyses for this date
    const allRaceAnalyses = await V75CacheService.getAllRaceAnalyses();
    
    const relevantAnalyses = allRaceAnalyses.filter(analysis => analysis.analysisDate === analysisDate);
    
    if (relevantAnalyses.length === 0) {
      throw new Error(`No races could be analyzed - no matching predictions found for ${analysisDate}`);
    }

    for (const actualRace of actualResults) {
      // Find matching cached prediction
      const cachedAnalysis = await V75CacheService.getRaceAnalysis(actualRace.raceId);
      
      if (!cachedAnalysis) {
        continue;
      }
      
      // Compare predictions with actual results using only cached data
      const raceAnalysis = this.compareRaceResults(actualRace, cachedAnalysis);
      races.push(raceAnalysis);
    }

    if (races.length === 0) {
      throw new Error('No races could be analyzed - no matching predictions found');
    }

    // Calculate overall performance metrics
    const overallPerformance = this.calculateOverallPerformance(races);

    return {
      gameId: `v75-${analysisDate}`,
      analysisDate,
      races,
      overallPerformance
    };
  }

  private static compareRaceResults(
    actualRace: any,
    cachedAnalysis: RaceAnalysisData
  ): V75RaceAnalysis {

    const predictionAccuracy: V75PredictionAccuracy[] = [];

    // Compare each horse's prediction vs actual result
    for (const cachedHorse of cachedAnalysis.horses) {
      const actualFinish = actualRace.finishOrder.find(
        (finish: any) => finish.horseId === cachedHorse.horseId
      );

      if (!actualFinish) {
        continue;
      }

      const accuracy: V75PredictionAccuracy = {
        horseId: cachedHorse.horseId,
        horseName: cachedHorse.horseName,
        postPosition: cachedHorse.postPosition,
        predictedScore: cachedHorse.finalScore,
        predictedRank: cachedHorse.rank,
        predictedTime: cachedHorse.predictedTime, // STRICT: Use only cached data
        actualFinishPosition: actualFinish.position,
        actualTime: actualFinish.kmTime,
        timeDifference: this.calculateTimeDifference(cachedHorse.predictedTime, actualFinish.kmTime),
        rankDifference: cachedHorse.rank - actualFinish.position,
        wasTopPick: cachedHorse.rank <= 3,
        actuallyPlaced: actualFinish.position <= 3,
        correctPrediction: cachedHorse.rank <= 3 && actualFinish.position <= 3
      };

      predictionAccuracy.push(accuracy);
    }

    // Calculate race-level accuracy metrics
    const overallAccuracy = this.calculateRaceAccuracy(predictionAccuracy);

    return {
      raceId: actualRace.raceId,
      raceNumber: actualRace.raceNumber,
      raceDate: actualRace.date || cachedAnalysis.analysisDate,
      distance: actualRace.distance,
      actualResults: actualRace,
      predictionAccuracy,
      overallAccuracy
    };
  }

  private static calculateTimeDifference(
    predictedTime?: { minutes: number; seconds: number; tenths: number },
    actualTime?: { minutes: number; seconds: number; tenths: number }
  ): number | undefined {
    if (!predictedTime || !actualTime) {
      return undefined;
    }

    if (predictedTime.minutes === undefined || predictedTime.seconds === undefined || predictedTime.tenths === undefined ||
        actualTime.minutes === undefined || actualTime.seconds === undefined || actualTime.tenths === undefined) {
      return undefined;
    }

    const predictedSeconds = predictedTime.minutes * 60 + predictedTime.seconds + predictedTime.tenths * 0.1;
    const actualSeconds = actualTime.minutes * 60 + actualTime.seconds + actualTime.tenths * 0.1;
    const difference = Math.abs(predictedSeconds - actualSeconds);

    return difference;
  }

  private static calculateRaceAccuracy(predictionAccuracy: V75PredictionAccuracy[]) {
    const topPicksCorrect = predictionAccuracy.filter(p => p.correctPrediction).length;
    const topPicksTotal = predictionAccuracy.filter(p => p.wasTopPick).length;
    const perfectPredictions = predictionAccuracy.filter(p => p.rankDifference === 0).length;
    
    const rankDifferences = predictionAccuracy.map(p => Math.abs(p.rankDifference));
    const averageRankDifference = rankDifferences.length > 0 
      ? rankDifferences.reduce((sum, diff) => sum + diff, 0) / rankDifferences.length 
      : 0;
    
    const meanAbsoluteError = averageRankDifference;

    // Calculate time MAE only for horses with predicted times
    const timeDifferences = predictionAccuracy
      .map(p => p.timeDifference)
      .filter(diff => diff !== undefined) as number[];
    
    const timeMAE = timeDifferences.length > 0
      ? timeDifferences.reduce((sum, diff) => sum + diff, 0) / timeDifferences.length
      : undefined;


    // Find best time predictions
    const bestActualHorse = predictionAccuracy.reduce((best, current) => 
      !best || (current.actualFinishPosition < best.actualFinishPosition) ? current : best
    );
    
    const bestPredictedHorse = predictionAccuracy.reduce((best, current) => 
      !best || (current.predictedRank < best.predictedRank) ? current : best
    );

    return {
      topPicksCorrect,
      topPicksTotal,
      averageRankDifference,
      perfectPredictions,
      meanAbsoluteError,
      timeMAE,
      bestTimeAccuracy: {
        predictedBest: bestPredictedHorse.horseName,
        actualBest: bestActualHorse.horseName,
        correctBestPrediction: bestPredictedHorse.horseId === bestActualHorse.horseId
      }
    };
  }

  private static calculateOverallPerformance(races: V75RaceAnalysis[]) {
    const totalRaces = races.length;
    
    const accuracySum = races.reduce((sum, race) => 
      sum + (race.overallAccuracy.topPicksCorrect / race.overallAccuracy.topPicksTotal), 0
    );
    const averageAccuracy = accuracySum / totalRaces;

    const raceAccuracies = races.map(race => 
      race.overallAccuracy.topPicksCorrect / race.overallAccuracy.topPicksTotal
    );
    const bestRaceAccuracy = Math.max(...raceAccuracies);
    const worstRaceAccuracy = Math.min(...raceAccuracies);

    const overallMAE = races.reduce((sum, race) => 
      sum + race.overallAccuracy.meanAbsoluteError, 0
    ) / totalRaces;

    const overallTimeMAE = races
      .map(race => race.overallAccuracy.timeMAE)
      .filter(mae => mae !== undefined)
      .reduce((sum, mae, _, arr) => sum + mae! / arr.length, 0) || undefined;

    const bestTimesPredicted = races.filter(race => 
      race.overallAccuracy.bestTimeAccuracy?.correctBestPrediction
    ).length;


    return {
      totalRaces,
      averageAccuracy,
      bestRaceAccuracy,
      worstRaceAccuracy,
      overallMAE,
      overallTimeMAE,
      bestTimesPredicted
    };
  }
}
